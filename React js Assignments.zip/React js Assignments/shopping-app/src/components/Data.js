export const Data = [
    {
      id: 1,
      image: "pic1.jpg",
      name: "Cotton Shirt",
      price: 450,
    },
    {
      id: 2,
      image: "pic2.jpg",
      name: "White Tshirt",
      price: 500,
    },
    {
      id: 3,
      image: "pic3.jpg",
      name: "Full Sleeve Tshirt",
      price: 270,
    },
    {
      id: 4,
      image: "pic4.jpg",
      name: "Fashion Men Black Shirt Slim Fit",
      price: 600,
    },
  ];